#include "Percetron.h"

Percetron::Percetron()
{
}
